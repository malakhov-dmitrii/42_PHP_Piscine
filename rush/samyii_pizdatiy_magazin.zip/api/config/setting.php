<?php
// define ('HOST', '192.168.29.120');
// define ('USER', 'gkoch');
// define ('PASS', '1234Aa!!');
// define ('DB', 'online_store');

define ('HOST', 'localhost');
define ('USER', 'root');
define ('PASS', '12345678');
define ('DB', 'online_store');