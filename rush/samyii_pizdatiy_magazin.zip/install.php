#!/usr/bin/php
<?PHP

echo `mysql -u root -p < ./online_store.sql`;

?>
